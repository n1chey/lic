# lic-environment
This is a program recorded for a drone that flies over the whole of Azerbaijan
DO NOT USE FOR COMERCIAL
